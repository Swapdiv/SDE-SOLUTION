require('dotenv').config();
const express = require('express');
const bodyParser = require("body-parser");
const path = require('path');

const app = express();
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(bodyParser.urlencoded({
  extended: true
}));

app.use(bodyParser.json());

//navigate to login page
app.get('/', (req, res) => { 
    res.render('pages/login');
});

// call post method to submit login form
app.post('/submitForm', (req, res) => { 
  const { email, password } = req.body;

  console.log('Email:', email);
  console.log('Password:', password);

  if (email == password) {
    console.log(123456)
    res.redirect('/enter-otp');
  } else {
    res.redirect('/failure');
  }
});

// call post method to submit otp from otp page
app.post('/submitOTP', (req, res) => {
  const { otp } = req.body;

  console.log('otp:', otp);
  if(otp == 123456){
    res.redirect('/success');
  }else{
    res.redirect('/failure');
  }
 
});

app.post('/backToLoginPage', (req, res) => {
  res.redirect('/');
});

app.get('/enter-otp', (req, res) => {
  res.render('pages/otp');
})

app.get('/success', (req, res) => {
  res.render('pages/success');
})

app.get('/failure', (req, res) => {
  res.render('pages/failure');
})

const port = 4200;
app.listen(port, () => console.log(`Listening on the port ${port}`));

